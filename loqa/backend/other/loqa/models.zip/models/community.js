const mongus = require('mongoose')

const communitySchema = new mongus.Schema({

    members: {type:Array, required:true},
    chatChannels: {type:Array, required:false, default:[]},
    rules: {type:String, required:false, default:"1. no amongus\n2. no amongus"},
    settings: {type:Object, required:false, default:{futureMeProblem:true}}
}, {timestamps:true})

module.exports = mongus.model('communities', communitySchema)